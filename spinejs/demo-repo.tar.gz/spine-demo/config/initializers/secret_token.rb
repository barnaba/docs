# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
SpineDemo::Application.config.secret_token = 'dacbfe754efe90dd1673849cdfcc45a63a2acfb0d665838e2c5be52d3f448817c0bfee4ffba712468ecbdd3e9c11f7a47c6fbb2d2d80c5db7feeaaf6e2b59874'
